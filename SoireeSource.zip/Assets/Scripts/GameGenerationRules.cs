using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UIElements;
using static Unity.Burst.Intrinsics.X86;
using Random = UnityEngine.Random;

public enum EmotionalState
{
    Resoluto,
    Impaciente,
    Enfurecido,
    Perturbado,
    Cauteloso,
    Curioso,
    Amedrontado,
    Atonito,
    Aliviado
}

public enum Alibi
{
    SalaoPrincipal,
    SalaDeDanca,
    SalaDeMusica,
    Jardim,
    Banheiro,
    Cozinha,
    HallDeEntrada,
    QuartoDeHospede,
    QuartoPrincipal,
    Biblioteca,
    Adega
}

public enum Role
{
    Assassino,
    Acusador,
    Aleatorio,
    Morto
}

public enum Opinion
{
    Positiva,
    Neutra,
    Negativa
}

public static class GameGenerationRules
{
    public static Dictionary<Role, List<EmotionalState>> RoleEmotionGrid = new Dictionary<Role, List<EmotionalState>>()
    {
        {
            Role.Assassino,
            new List<EmotionalState>() 
            {
                EmotionalState.Resoluto,
                EmotionalState.Impaciente,
                EmotionalState.Enfurecido,
                EmotionalState.Perturbado,
                EmotionalState.Cauteloso,
                EmotionalState.Curioso
            } 
        },
        { 
            Role.Acusador,
            new List<EmotionalState>() 
            {
                EmotionalState.Resoluto,
                EmotionalState.Impaciente,
                EmotionalState.Enfurecido,
                EmotionalState.Amedrontado,
                EmotionalState.Atonito,
                EmotionalState.Aliviado
            } 
        },
        {
            Role.Aleatorio,
            new List<EmotionalState>() 
            {
                EmotionalState.Perturbado,
                EmotionalState.Cauteloso,
                EmotionalState.Curioso,
                EmotionalState.Amedrontado,
                EmotionalState.Atonito,
                EmotionalState.Aliviado
            } 
        }
    };

    public static int maxAlibis = 3;
    public static string GetAlibiString(Alibi alibi)
    {
        switch (alibi)
        {
            case Alibi.SalaoPrincipal:
                return "no Sal�o Principal";
            case Alibi.SalaDeDanca:
                return "na Sala de Dan�a";
            case Alibi.SalaDeMusica:
                return "na Sala de M�sica";
            case Alibi.Jardim:
                return "no Jardim";
            case Alibi.Banheiro:
                return "no Banheiro";
            case Alibi.Cozinha:
                return "na Cozinha";
            case Alibi.HallDeEntrada:
                return "no Hall de Entrada";
            case Alibi.QuartoDeHospede:
                return "no Quarto de H�spede";
            case Alibi.QuartoPrincipal:
                return "no Quarto Principal";
            case Alibi.Biblioteca:
                return "na Biblioteca";
            case Alibi.Adega:
                return "na Adega";
            default:
                return "em algum lugar desconhecido";
        }
    }

    static Dictionary<EmotionalState, string> EmotionalStateToStringM = new Dictionary<EmotionalState, string>()
    {
        { EmotionalState.Resoluto, "resoluto" },
        { EmotionalState.Impaciente, "impaciente" },
        { EmotionalState.Enfurecido, "enfurecido" },
        { EmotionalState.Perturbado, "perturbado" },
        { EmotionalState.Cauteloso, "cauteloso" },
        { EmotionalState.Curioso, "curioso" },
        { EmotionalState.Amedrontado, "amedrontado" },
        { EmotionalState.Atonito, "at�nito" },
        { EmotionalState.Aliviado, "aliviado"}
    };

    static Dictionary<EmotionalState, string> EmotionalStateToStringF = new Dictionary<EmotionalState, string>()
    {
        { EmotionalState.Resoluto, "resoluta" },
        { EmotionalState.Impaciente, "impaciente" },
        { EmotionalState.Enfurecido, "enfurecida" },
        { EmotionalState.Perturbado, "perturbada" },
        { EmotionalState.Cauteloso, "cautelosa" },
        { EmotionalState.Curioso, "curiosa" },
        { EmotionalState.Amedrontado, "amedrontada" },
        { EmotionalState.Atonito, "at�nita" },
        { EmotionalState.Aliviado, "aliviada"}
    };

    public static string GetEmotionalStateString(EmotionalState emotionalState, string characterName)
    {
        if (characterName == "Regnum" || characterName == "Solaris")
        {
            return EmotionalStateToStringM[emotionalState];
        }
        else
        {
            return EmotionalStateToStringF[emotionalState];
        }
    }

    public class RoleOpinionRelationship
    {
        public Role role;
        public Dictionary<Role, List<Opinion>> drawableOpinion;
    }

    public static List<RoleOpinionRelationship> roleOpinionRelationships = new List<RoleOpinionRelationship>()
    {
        new RoleOpinionRelationship() {
            role = Role.Assassino,
            drawableOpinion = new Dictionary<Role, List<Opinion>>()
            {
                { Role.Acusador, new List<Opinion>() { Opinion.Negativa } },
                { Role.Aleatorio, new List<Opinion>() { Opinion.Positiva, Opinion.Neutra, Opinion.Negativa } },
                { Role.Morto, new List<Opinion>() { Opinion.Positiva,  Opinion.Neutra} }
            }
        },
        new RoleOpinionRelationship() {
            role = Role.Acusador,
            drawableOpinion = new Dictionary<Role, List<Opinion>>()
            {
                { Role.Assassino, new List<Opinion>() { Opinion.Negativa } },
                { Role.Aleatorio, new List<Opinion>() { Opinion.Positiva, Opinion.Neutra, Opinion.Negativa } },
                { Role.Morto, new List<Opinion>() { Opinion.Positiva} }
            }
        },
        new RoleOpinionRelationship() {
            role = Role.Aleatorio,
            drawableOpinion = new Dictionary<Role, List<Opinion>>()
            {
                { Role.Acusador, new List<Opinion>() { Opinion.Positiva, Opinion.Neutra, Opinion.Negativa } },
                { Role.Assassino, new List<Opinion>() { Opinion.Positiva, Opinion.Neutra, Opinion.Negativa } },
                { Role.Aleatorio, new List<Opinion>() { Opinion.Positiva, Opinion.Neutra, Opinion.Negativa } },
                { Role.Morto, new List<Opinion>() { Opinion.Positiva, Opinion.Neutra, Opinion.Negativa } },
            }
        }
    };

    static List<string> positiveOpinionsString = new List<string>()
    {
        "{CHARACTER} � gentil com todos.",
        "Eu confio completamente em {CHARACTER}.",
        "Jamais ouvi falarem mal de {CHARACTER}.",
        "{CHARACTER} jamais faria uma coisa dessas.",
        "Conhe�o {CHARACTER} desde a inf�ncia, n�o � uma pessoa ruim."
    };

    static List<string> neutralOpinionsString = new List<string>()
    {
        "N�o conhe�o {CHARACTER} pessoalmente.",
        "N�o tenho como opinar sobre {CHARACTER}.",
        "{CHARACTER} tem uma vida bastante privada.",
        "{CHARACTER} sempre foi bastante independente.",
        "Eu e {CHARACTER} n�o fazemos parte do mesmo c�rculo de amizades."
    };


    static List<string> negativeOpinionsString = new List<string>()
    {
        "{CHARACTER} � uma p�ssima pessoa.",
        "N�o confio nem um pouco em {CHARACTER}.",
        "S� escuto falarem mal de {CHARACTER}.",
        "N�o me surpreenderia se {CHARACTER} for culpado.",
        "N�o gosto de {CHARACTER} desde a inf�ncia."
    };

    static List<string> positiveOpinionsDeadString = new List<string>()
    {
        "{CHARACTER} era gentil com todos.",
        "Eu n�o acredito que {CHARACTER} se foi.",
        "Quem faria uma coisa dessas com {CHARACTER}.",
        "Conhecia {CHARACTER} desde a inf�ncia, n�o era sua hora."
    };

    static List<string> neutralOpinionsDeadString = new List<string>()
    {
        "N�o conheci {CHARACTER} pessoalmente.",
        "N�o tenho como opinar sobre {CHARACTER}.",
        "{CHARACTER} tinha uma vida bastante privada.",
        "Eu e {CHARACTER} n�o faz�amos parte do mesmo c�rculo de amizades."
    };


    static List<string> negativeOpinionsDeadString = new List<string>()
    {
        "{CHARACTER} era uma p�ssima pessoa.",
        "N�o confiava nem um pouco em {CHARACTER}.",
        "Falavam t�o mal de {CHARACTER} que uma hora isso ia acontecer.",
        "N�o gosto de {CHARACTER} desde a inf�ncia."
    };

    static Dictionary<Opinion, List<string>> opinionStringDict = new Dictionary<Opinion, List<string>>()
    {
        { Opinion.Positiva, positiveOpinionsString },
        { Opinion.Neutra, neutralOpinionsString },
        { Opinion.Negativa, negativeOpinionsString }
    };

    static Dictionary<Opinion, List<string>> opinionDeadStringDict = new Dictionary<Opinion, List<string>>()
    {
        { Opinion.Positiva, positiveOpinionsDeadString },
        { Opinion.Neutra, neutralOpinionsDeadString },
        { Opinion.Negativa, negativeOpinionsDeadString }
    };

    public static string GetOpinionString(Opinion opinionType, string characterName)
    {
        string randomMessage = opinionStringDict[opinionType][Random.Range(0, opinionStringDict[opinionType].Count)];
        randomMessage = randomMessage.Replace("{CHARACTER}", characterName);
        return randomMessage;
    }

    public static string GetOpinionDeadString(Opinion opinionType, string characterName)
    {
        string randomMessage = opinionDeadStringDict[opinionType][Random.Range(0, opinionDeadStringDict[opinionType].Count)];
        randomMessage = randomMessage.Replace("{CHARACTER}", characterName);
        return randomMessage;
    }
}
