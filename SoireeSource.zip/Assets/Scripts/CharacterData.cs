using Doublsb.Dialog;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using static GameGenerationRules;
using Random = UnityEngine.Random;

public class CharacterData : MonoBehaviour
{
    public string characterName;
    public Role role;
    public EmotionalState emotionalState;
    public Alibi alibi;
    public List<string> startMessages;
    public List<string> sameAlibiCharacters;
    public string alibiMessage;
    public List<string> opinionMessages;
    public bool revealedAlibi;
    public bool revealedOpinions;

    public CharacterData(string characterName, Role role, EmotionalState emotionalState, Alibi alibi)
    {
        this.characterName = characterName;
        this.role = role;
        this.emotionalState = emotionalState;
        this.alibi = alibi;

        revealedAlibi = false;
        revealedOpinions = false;

        this.alibiMessage = "";
    }

    public void GenerateAlibiMessage()
    {
        switch (role)
        {
            case Role.Assassino:
                alibiMessage = GetMurdererAlibi();
                break;
            case Role.Aleatorio:
                alibiMessage = GetAleatorioAlibi();
                break;
            case Role.Acusador:
                alibiMessage = GetAcusadorAlibi();
                break;
        }
    }

    public void GenerateOpinions()
    {
        switch (role)
        {
            case Role.Assassino:
                opinionMessages = GetAssassinoOpinions();
                break;
            case Role.Aleatorio:
                opinionMessages = GetAleatorioOpinions();
                break;
            case Role.Acusador:
                opinionMessages = GetAcusadorOpinions();
                break;
        }
    }

    public override string ToString()
    {
        return string.Format($"{characterName}: {role} {alibi} {emotionalState} {string.Join(',',sameAlibiCharacters)}");
    }

    public override bool Equals(object other)
    {
        CharacterData otherCharacter = other as CharacterData;
        return this.characterName == otherCharacter.characterName && this.role == otherCharacter.role;
    }

    public List<DialogData> GenerateDialogData()
    {
        List<DialogData> dialogTexts = new List<DialogData>();
        /*foreach (var message in this.startMessages)
        {
            dialogTexts.Add(new DialogData(message, this.characterName));
        }*/
        DialogData dialogData = new DialogData($"/color:red/{this.characterName} parece {GameGenerationRules.GetEmotionalStateString(this.emotionalState, characterName)}.", this.characterName);
        dialogData.SelectList.Add("Alibi", "Onde voc� estava?");
        dialogData.SelectList.Add("Opiniao", "O que voc� acha dos outros?");
        dialogData.Callback = () => CheckOption();
        dialogTexts.Add(dialogData);
        return dialogTexts;
    }

    void RevealAlibi()
    {
        Debug.Log("Revealed Alibi");
        this.revealedAlibi = true;
        GameManager.Instance.UpdateUI(this);
    }

    void RevealOpinions()
    {
        this.revealedOpinions = true;
        GameManager.Instance.UpdateUI(this);
    }

    void CheckOption()
    {
        if (GameManager.Instance.dialogManager.Result == "Alibi")
        {
            var dialogTexts = new List<DialogData>();
            dialogTexts.Add(new DialogData(this.alibiMessage, this.characterName));
            GameManager.Instance.dialogManager.Show(dialogTexts);
            RevealAlibi();
        }
        else if (GameManager.Instance.dialogManager.Result == "Opiniao")
        {
            var dialogTexts = new List<DialogData>();
            for (int i = 0; i < this.opinionMessages.Count; i++)
            {
                dialogTexts.Add(new DialogData(opinionMessages[i], this.characterName));
            }
            RevealOpinions();
            GameManager.Instance.dialogManager.Show(dialogTexts);
        }
    }

    string GetGeneralAlibi()
    {
        return $"Eu estava {GameGenerationRules.GetAlibiString(this.alibi)}.";
    }

    string GetAlibiCharacters(List<string> characterNames, bool positive = true, bool nominal = true)
    {
        if (positive)
        {
            if (characterNames.Count == 0)
            {
                return $"Eu estava sozinho.";
            }
            else if (characterNames.Count == 1)
            {
                if (nominal)
                { 
                    return $"Eu vi {characterNames[0]}.";
                }
                else
                {
                    return $"Eu vi uma pessoa.";
                }
            }
            else
            {
                string message = "";
                if (nominal)
                {
                    message = $"Eu vi ";
                    for (int i = 0; i < characterNames.Count; i++)
                    {
                        if (i != characterNames.Count - 1)
                        {
                            message += $"{characterNames[i]}, ";
                        }
                        else
                        {
                            message += $"e {characterNames[i]}.";
                        }
                    }
                    return message;
                }
                else
                {
                    return $"Eu vi {characterNames.Count} pessoas.";
                }
                
            }
        }
        else
        {
            if (characterNames.Count == 0)
            {
                return $"Eu n�o vi mais ningu�m.";
            }
            else if (characterNames.Count == 1)
            {
                return $"Eu n�o vi {characterNames[0]}.";
            }
            else
            {
                string message = $"Eu n�o vi ";
                for (int i = 0; i < characterNames.Count; i++)
                {
                    if (i != characterNames.Count - 1)
                    {
                        message += $"{characterNames[i]}, ";
                    }
                    else
                    {
                        message += $"e {characterNames[i]}.";
                    }
                }
                return message;
            }
        }
    }

    string GetMurdererAlibi()
    {
        string message = GetGeneralAlibi();
        //Ao gerar o alibi do assassino, consideramos uma frase positiva ou negativa de forma aleat�ria.
        //Na frase positiva, o personagem viu os personagens listados em sameAlibiCharacters. Na frase negativa,
        //o personagem n�o viu algum personagem que de fato estava na mesma sala que ele diz estar.
        bool positive = Random.Range(0, 2) == 0;
        if (positive)
        {
            message += $" {GetAlibiCharacters(sameAlibiCharacters)}";
        }
        else
        {
            List<CharacterData> realAlibiCharacters = GameManager.Instance.GetCharactersWithAlibi(this.alibi)
                .Where(x=>x.characterName!=this.characterName).ToList();
            List<CharacterData> lieAlibiCharacters = realAlibiCharacters.Randomize().Take(Random.Range(1, realAlibiCharacters.Count - 1)).ToList();
            message += $" {GetAlibiCharacters(lieAlibiCharacters.Select(x=>x.characterName).ToList(), false)}";
        }
        return message;
    }

    string GetAcusadorAlibi()
    {
        string message = GetGeneralAlibi();
        //O acusador pode dar duas informa��es: uma informa��o (pode ser parcial) sobre os personagens na sala dele e
        //uma informa��o espec�fica sobre o assassino.
        //Primeiro, determino aleatoriamente se o acusador vai informar sobre os personagens na sala dele.
        bool willInformAboutRoom = Random.Range(0,2) == 0;
        // Em seguida, determino aleatoriamente se a informa��o ser� completa ou n�o.
        bool willInformAboutRoomCompleteInformation = Random.Range(0, 2) == 0;
        if (willInformAboutRoom)
        { 
            // Em seguida, determino se a informa��o ser� positiva ou negativa.
            bool positiveInformation = Random.Range(0, 2) == 0;
            // Finalmente, determino se a informa��o � nominal ou n�o nominal.
            bool nominalInformation = Random.Range(0, 2) == 0;
            // Agora construo a mensagem a partir dessas decis�es.
            List<string> characterNamesToMention = willInformAboutRoomCompleteInformation ?
                sameAlibiCharacters :
                sameAlibiCharacters.Randomize().Take(Random.Range(1, sameAlibiCharacters.Count)).ToList();
            message += $" {GetAlibiCharacters(characterNamesToMention, positiveInformation, nominalInformation)}";
        }
        //Agora adiciono a informa��o relacionada ao assassino.
        CharacterData murdererData = GameManager.Instance.GetMurdererData();
        //Primeiro, checo se o acusador estava na mesma sala que o assassino. Ou seja, o assassino est� mentindo
        //e o acusador tentar� desmintir. Verifico tamb�m se a informa��o dada pelo acusador � incompleta, se for,
        //o acusador aponta diretamente que o assassino n�o estava na sala.
        if (murdererData.alibi == this.alibi)
        {
            if (!willInformAboutRoomCompleteInformation)
            {
                message += $" Eu n�o vi {murdererData.characterName}";
            }
        }
        return message;
    }

    string GetAleatorioAlibi()
    {
        string message = GetGeneralAlibi();
        //O aleatorio d� uma informa��o possivelmente parcial sobre a sala em que est�.
        // Em seguida, determino aleatoriamente se a informa��o ser� completa ou n�o.
        bool willInformAboutRoomCompleteInformation = Random.Range(0, 2) == 0;
        // Em seguida, determino se a informa��o ser� positiva ou negativa.
        bool positiveInformation = Random.Range(0, 2) == 0;
        // Finalmente, determino se a informa��o � nominal ou n�o nominal.
        bool nominalInformation = Random.Range(0, 2) == 0;
        // Agora construo a mensagem a partir dessas decis�es.
        List<string> characterNamesToMention = new List<string>();
        if (willInformAboutRoomCompleteInformation)
        {
            characterNamesToMention = positiveInformation ? sameAlibiCharacters :
                GameManager.Instance.GetComplementarListCharacters(sameAlibiCharacters);
        }
        else
        {
            characterNamesToMention = positiveInformation ?
                sameAlibiCharacters.Randomize().Take(Random.Range(1, sameAlibiCharacters.Count)).ToList() :
                GameManager.Instance.GetComplementarListCharacters(
                    sameAlibiCharacters.Randomize().Take(Random.Range(1, sameAlibiCharacters.Count)).ToList());
        }
        if (characterNamesToMention.Count > 0) { 
            characterNamesToMention = characterNamesToMention.Where(x => x != this.characterName).ToList();
        }
        message += $" {GetAlibiCharacters(characterNamesToMention, positiveInformation, nominalInformation)}";
        return message;
    }

    public string GetMortoOpinion(RoleOpinionRelationship roleOpinionRelationship)
    {
        List<Opinion> drawableOpinions = roleOpinionRelationship.drawableOpinion[Role.Morto];
        Opinion selectedOpinion = drawableOpinions[Random.Range(0, drawableOpinions.Count)];
        return GetOpinionDeadString(selectedOpinion, GameManager.Instance.deadCharacterName);
    }

    public List<string> GetGeneralOpinion()
    {
        List<string> opinions = new List<string>();
        RoleOpinionRelationship roleOpinionRelationship = GameGenerationRules.roleOpinionRelationships
            .Where(x => x.role == this.role).First();
        foreach (CharacterData toOpinate in GameManager.Instance.characterDataDict.Values)
        {
            if (roleOpinionRelationship.drawableOpinion.ContainsKey(toOpinate.role) && !this.Equals(toOpinate))
            {
                List<Opinion> drawableOpinions = roleOpinionRelationship.drawableOpinion[toOpinate.role];
                Opinion selectedOpinion = drawableOpinions[Random.Range(0, drawableOpinions.Count)];
                opinions.Add(GetOpinionString(selectedOpinion, toOpinate.characterName));
            }
        }
        opinions.Add(GetMortoOpinion(roleOpinionRelationship));
        return opinions;
    }

    public List<string> GetAssassinoOpinions()
    {
        return GetGeneralOpinion();
    }
    public List<string> GetAleatorioOpinions()
    {
        return GetGeneralOpinion();
    }
    public List<string> GetAcusadorOpinions()
    {
        List<string> opinions = new List<string>();
        RoleOpinionRelationship roleOpinionRelationship = GameGenerationRules.roleOpinionRelationships
            .Where(x => x.role == this.role).First();
        bool firstAleatorio = true;
        foreach (CharacterData toOpinate in GameManager.Instance.characterDataDict.Values)
        {
            if (roleOpinionRelationship.drawableOpinion.ContainsKey(toOpinate.role))
            {
                if (toOpinate.role == Role.Aleatorio && firstAleatorio)
                {
                    Opinion selectedOpinion = Opinion.Negativa;
                    opinions.Add(GetOpinionString(selectedOpinion, toOpinate.characterName));
                    firstAleatorio = false;
                }
                else
                {
                    List<Opinion> drawableOpinions = roleOpinionRelationship.drawableOpinion[toOpinate.role];
                    Opinion selectedOpinion = drawableOpinions[Random.Range(0, drawableOpinions.Count)];
                    opinions.Add(GetOpinionString(selectedOpinion, toOpinate.characterName));
                }
            }
        }
        opinions.Add(GetMortoOpinion(roleOpinionRelationship));
        return opinions;
    }

}
